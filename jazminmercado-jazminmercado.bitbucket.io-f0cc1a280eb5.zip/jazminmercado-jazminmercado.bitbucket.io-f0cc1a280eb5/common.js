{ 
    "https://www.https://bitbucket.org/jazminmercado-admin/jazminmercado.bitbucket.io/src/master/.bitucbket"
}
{vscode-edge-devtools.defaultUrl ;  https://www.jazminmercado.bitbucket.io
vscode-edge-devtools.userDataDir 
}