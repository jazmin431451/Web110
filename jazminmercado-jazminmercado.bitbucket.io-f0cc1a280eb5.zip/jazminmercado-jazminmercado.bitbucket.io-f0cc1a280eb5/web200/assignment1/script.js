
document.addEventListener("DOMContentLoaded", function() {
    var name = "jazmin";
    document.getElementById("output").innerHTML = "Hello " + name + "!";
    console.log("Hello " + name + "!");
});
